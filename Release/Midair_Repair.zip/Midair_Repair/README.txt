Author: Zackery Mason-Blaug

Github: https://github.com/ZackMason/Midair-Repair/

This program was compiled for win 32
raylib supports many different platforms 
so there might be a port later

How to Play:
	Use the mouse to steer the airplane.
	Use the mouse to solve puzzles.
	Every click costs health, so be careful.
	Solve puzzles to repair the plane.
	Puzzles consist of a series of dots, connected by lines.
	You must find the start of the path and click the dots in order.
	Some of the dots might be broken, don't let them trick you.

	Press R to respawn your airplane
	Press space to shoot missiles (they don't do anything)

